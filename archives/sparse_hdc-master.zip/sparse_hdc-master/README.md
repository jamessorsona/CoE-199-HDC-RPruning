# sparse_hdc
preliminary work for accuracy checks on sparse hdc

# Please load models from the CoE199 drive
